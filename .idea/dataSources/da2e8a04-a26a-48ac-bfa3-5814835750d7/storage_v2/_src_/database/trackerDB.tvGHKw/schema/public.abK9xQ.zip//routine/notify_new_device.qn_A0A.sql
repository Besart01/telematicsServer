create function notify_new_device() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Notify the addition of a new device (you can customize the message)
    PERFORM pg_notify('new_device_added', NEW.imei);
    RETURN NEW;
END;
$$;

alter function notify_new_device() owner to intelory;

